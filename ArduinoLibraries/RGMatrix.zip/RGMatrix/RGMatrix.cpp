#include <SPI.h>
#include "RGMatrix.h"

#include "Arduino.h"

extern const byte font8x8[];  // 8X8 fonts to display letters located in RGMatrix.h

extern char screenBuffer[NUM_PIXELS];
extern char screenDisplay[NUM_PIXELS];

cRGMatrix RGMatrix;  //Create an instance of the class for use in the library

/*
  RG Class constructor
  Inputs: none
  Usage: RGMatrix myMatrix();
*/
cRGMatrix::cRGMatrix(void)
{
  //Do Nothing
}

/*
  Configures SPI and I/O for communication with an RG Matrix.
  Note: Pinout should reflect the pin assignments in the cRGMatrix.h file
*/
void cRGMatrix::begin()
{
  //Set the pin modes for the RG matrix
  pinMode(SLAVESELECT,OUTPUT);  
  
  // initialize SPI:
  SPI.begin();
  SPI.setClockDivider(SPI_CLOCK_DIV128);
  delay(500);

  //Clear the screen
  clear();
  
}

/*
  Sets the color of a pixel on the board
  Note: display won't be updated until display() function is called
  Inputs:
      int row - The row of the pixel to be set
      int column - The column of the pixel to be set
      char color - The color to be used for the pixel fill.
  Returns: 1 - Success
           0 - Failure (invalid row or column)
*/
char cRGMatrix::fillPixel(int row, int column, char color)
{
  
  if((column < 0) || (column > NUM_COLUMNS-1))return 0;
  if((row < 0) || (row > NUM_ROWS-1))return 0;
  if((color < 0) || (color > NUM_COLORS-1))return 0;
  
  screenBuffer[column*NUM_COLUMNS+row]=color;
}

/*
  Fills a column in the screenBuffer.
  Note: display won't be updated until display() function is called.
  Inputs:
      int column - The column number to be filled
      char color - The color used for the fill
  Returns: 1 - Success
       0 - Failure (causes are invalued screen or column number)
*/
char cRGMatrix::fillColumn(int column, char color)
{

  if((column < 0) || (column > NUM_COLUMNS-1))return 0;
  if((color < 0) || (color > NUM_COLORS-1))return 0;

  for(int row=0; row<NUM_ROWS; row++)
  {
      screenBuffer[column*NUM_COLUMNS+row]=color;
  }

  return 1;
}

/* 
  Fills a row in the screenBuffer.
  Note: display won't be updated until the display() function is called
  Inputs:
      int row - The row to be filled
      char color - The color to be used for the fill
  Returns: 1 - Success
       0 - Failure (invalid screen or row)
*/
char cRGMatrix::fillRow(int row, char color)
{

  if((row < 0) || (row > NUM_ROWS-1))return 0;
  if((color < 0) || (color > NUM_COLORS-1))return 0;
  
  for(int column=0; column<NUM_COLUMNS; column++)
  {
      screenBuffer[column*NUM_COLUMNS+row]=color;
  }
  return 1;  
}

/*
  Fills the screenBuffer
  Note: display won't be updated until the display() function is called.
  Inputs:
      char color - The color to be used for the fill.
  Returns: 1 - Success
       0 - Failure (invalid board)
*/
char cRGMatrix::fillScreen(char color)
{

  if((color < 0) || (color > NUM_COLORS-1))return 0;

  for(int row=0; row<NUM_ROWS; row++)
  {
    for(int column=0; column<NUM_COLUMNS; column++)
    {
        screenBuffer[column*NUM_COLUMNS+row]=color;
    }
  }
  return 1;
}

/*
  Puts a character into the screenBuffer
  Note: display won't be updated until the display() function is called.
  Inputs:
      char letter - The letter to put onto the screen
      char color - The color of the letter
  Returns: 1 - Success
*/
char cRGMatrix::fillChar(char letter, char color)
{

  if((color < 0) || (color > NUM_COLORS-1))return 0;

  if ((letter >= 0x20) && (letter <= 0x7F) )
    letter=letter-0x20;
  else
    letter=0; //space
  
  for(int column=0; column<NUM_COLUMNS; column++)
  {
    for(int row=0; row<NUM_ROWS; row++)
    {
      if (bitRead(font8x8[(letter*NUM_ROWS)+row],7-column)) {
        screenBuffer[column*NUM_COLUMNS+row]=color;
      }
    }
  }
  
  return 1;
}
char cRGMatrix::fillStuff(char letter, char color)
{

  if((color < 0) || (color > NUM_COLORS-1))return 0;

  for(int column=0; column<NUM_COLUMNS; column++)
  {
    for(int row=0; row<NUM_ROWS; row++)
    {
      if (bitRead(stuff8x8[(letter*NUM_ROWS)+row],7-column)) {
        screenBuffer[row*NUM_COLUMNS+column]=color;
      }
    }
  }
  
  return 1;
}
/*
  Clears the screen
*/
void cRGMatrix::clear(void)
{
  fillScreen(BLACK);
  display();
}

/*
  Sends the data in screenBuffer to the screen
  and copy to the display buffer.
*/
void cRGMatrix::display(void)
{
  sendScreen(screenBuffer);  //Send frame data over SPI.
  // copy screenBuffer to screenDisplay
  for(int index=0; index<NUM_PIXELS; index++)
  {
    screenDisplay[index]=screenBuffer[index] ;
  }
}

/*
  Scroll the data in screenBuffer to screen
  and copy to the display buffer.  
*/
void cRGMatrix::scroll(int speed)
{
  char screenScroll[NUM_PIXELS*2];

  //copy display and screen to scroll
  for(int index=0; index<NUM_PIXELS; index++)
  {
    screenScroll[index]=screenDisplay[index] ;
  }
  for(int index=0; index<NUM_PIXELS; index++)
  {
    screenScroll[index+NUM_PIXELS]=screenBuffer[index] ;
  }

  for(int column=0;column<NUM_COLUMNS;column++) {
    sendScreen(&screenScroll[column*NUM_ROWS]);
    delay(speed);
  }

  display();
}

void cRGMatrix::scrollMessage(String message, int color, int speed)
{

  for(int i=0;i<message.length();i++)
  {
    fillScreen(BLACK);
    fillChar(message[i], color);
    scroll(speed);
  }

}

void cRGMatrix::scrollMessage(String message)
{

  int currentColor = GREEN;
  int speed = 50;

  for(int i=0;i<message.length();i++)
  {
    fillScreen(BLACK);
    if ((message[i]=='/')&&(i!=message.length()-1)) {
      i++;
      switch (message[i]) {
      case '1':
        speed=200;
        break;
      case '2':
        speed=100;
        break;
      case '3':
        speed=50;
        break;
      case '4':
        speed=37;
        break;
      case '5':
        speed=15;
        break;
      case RED_SYM:
        currentColor=RED;
        break;
      case GREEN_SYM:
        currentColor=GREEN;
        break;
      case ORANGE_SYM:
        currentColor=ORANGE;
        break;
      case '/':
        fillChar(message[i], currentColor);
        scroll(speed);
        break;
      case ROUND_SYM:
        fillStuff(ROUND, currentColor);
        scroll(speed);
        break;
      case BOX_SYM:
        fillStuff(BOX, currentColor);
        scroll(speed);
        break;
      case FINE_CHECK_SYM:
        fillStuff(FINE_CHECK, currentColor);
        scroll(speed);
        break;
      case BIG_CHECK_SYM:
        fillStuff(BIG_CHECK, currentColor);
        scroll(speed);
        break;
      case X_PATTERN_SYM:
        fillStuff(X_PATTERN, currentColor);
        scroll(speed);
        break;
      case SPRIAL_SYM:
        fillStuff(SPRIAL, currentColor);
        scroll(speed);
        break;
      case CHAIN_LINK_SYM:
        fillStuff(CHAIN_LINK, currentColor);
        scroll(speed);
        break;
      case GHOST_SYM:
        fillStuff(GHOST, currentColor);
        scroll(speed);
        break;
      case PACMAN_SYM:
        fillStuff(PACMAN, currentColor);
        scroll(speed);
        break;
      case CHECK_EDGES_SYM:
        fillStuff(CHECK_EDGES, currentColor);
        scroll(speed);
        break;
      case ROCKET_SYM:
        fillStuff(ROCKET, currentColor);
        scroll(speed);
        break;
      case HOUSE_SYM:
        fillStuff(HOUSE, currentColor);
        scroll(speed);
        break;
      case V_STRIPES_SYM:
        fillStuff(V_STRIPES, currentColor);
        scroll(speed);
        break;
      case H_STRIPES_SYM:
        fillStuff(H_STRIPES, currentColor);
        scroll(speed);
        break;
      case D_STRIPES_R_SYM:
        fillStuff(D_STRIPES_R, currentColor);
        scroll(speed);
        break;
      case D_STRIPES_L_SYM:
        fillStuff(D_STRIPES_L, currentColor);
        scroll(speed);
        break;
      case ARROW_TAIL_SYM:
        fillStuff(ARROW_TAIL, currentColor);
        scroll(speed);
        break;
      case ARROW_HEAD_SYM:
        fillStuff(ARROW_HEAD, currentColor);
        scroll(speed);
        break;
      case CHEVRON_R_SYM:
        fillStuff(CHEVRON_R, currentColor);
        scroll(speed);
        break;
      case FROWN_SYM:
        fillStuff(FROWN, currentColor);
        scroll(speed);
        break;
      case SMILE_SYM:
        fillStuff(SMILE, currentColor);
        scroll(speed);
        break;
      case HEART_SYM:
        fillStuff(HEART, currentColor);
        scroll(speed);
        break;
      case H_HEART_SYM:
        fillStuff(H_HEART, currentColor);
        scroll(speed);
        break;
      }
    } else {
      fillChar(message[i], currentColor);
      scroll(speed);
    }
  }
}


/*
  Sends NUM_PIXELS to the screen
*/
void cRGMatrix::sendScreen(char * screen)
{
  digitalWrite(SLAVESELECT, LOW);
  delayMicroseconds(500); 

  for(int row=0; row<NUM_ROWS; row++)
  {
      for(int column=0; column<NUM_COLUMNS; column++)
      {
          SPI.transfer(screen[column*NUM_COLUMNS+row]);
      }
  }

  digitalWrite(SLAVESELECT, HIGH);
  delayMicroseconds(500); 

}
